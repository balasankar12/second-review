<?php include('hslogin.php') ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
	<script src="https://maps.google.com/maps/api/js?sensor=false" type="text/javascript"></script>
	<title>Mid Road Helper</title>
    <link href="assets/img/logo.png" rel="icon">
    <link rel="stylesheet" href="assets/css/head.css" /> 
    <link rel="stylesheet" href="assets/css/table.css" />
    <link rel="stylesheet" href="assets/css/profile.css" />  
    <style type="text/css">
		#map {
			width: 200px;
			height: 200px;
		}
		#hsmap{
			width: 200px;
			height: 200px;
		}
		</style>
</head>

<body>
    <div class="header">
        <div class="row" >
            <div class="logo">
                <img src="assets/img/logo.png">
            </div>
            <div >
                <div style="float:right;margin-right: 100px;color:royalblue;font-size:25px;">
                    <?php echo "Welcome ".$_SESSION['hsname'];?>    
                </div>
                <div class="dnav">
                    <ul class="main-nav">
                        <li style="margin-right: 400px; color:#FFFFFF"><h1>MIDROAD HELPER</h1></li>
                        <li><a href="hshome.php">HOME</a></li>
                    </ul>
                </div>
            </div>
            

        </div>
    </div>
            <div>
			<?php
				include('connection.php');
				$sql1="select u.name,u.mail_id,u.number,c.user_latitude,user_longitude,c.hs_id,c.user_id,c.vehiclename,c.problem from user_details u,connect_user_hs c where u.user_id=c.user_id and c.hs_id='".$_SESSION['hsid']."' and status=1";
				$result1 = $conn->query($sql1);
				if ($result1->num_rows > 0) {
                    
                while($row1 = $result1->fetch_assoc()) {
                echo '<div class="page-wrapper bg-gra-02 p-t-130 p-b-100 font-poppins">
			
				<h2 class="title">Detail of Customer</h2>
					<div class="wrapper wrapper--w680">
						<div class="card card-4">
							<div class="card-body">
									<div class="row row-space">
										<div class="col-2">
											<label class="label">Customer Name</label>
											<input class="input--style-4" type="text" name="cname" value="'. $row1["name"].'" readonly> </div>
									</div>
									<div class="row row-space">
										<div class="col-2">
											<label class="label">E-Mail</label>
											<input class="input--style-4 js-datepicker" type="text" name="cmail" value="'. $row1["mail_id"].'" readonly> </div>
									</div>
									<div class="row row-space">
										<div class="col-2">
											<label class="label">Number</label>
											<input class="input--style-4 js-datepicker" type="text" name="cnumber" value="'. $row1["number"].'" readonly> </div>
									</div>
									<div class="row row-space">
										<div class="col-2">
											<label class="label">Location</label>
											<div id="map"></div>
									</div>
									
									<div class="row row-space">
										<div class="col-2">
											<label class="label">Latitude</label>
											<input class="input--style-4 js-datepicker" type="text" name="lat" value="'. $row1["user_latitude"].'" readonly> </div>
									</div>
									<div class="row row-space">
										<div class="col-2">
											<label class="label">Longitude</label>
											<input class="input--style-4 js-datepicker" type="text" name="lon" value="'. $row1["user_longitude"].'" readonly> </div>
									</div>
									<div class="row row-space">
										<div class="col-2">
											<label class="label">Vehicle</label>
											<input class="input--style-4 js-datepicker" type="text" name="vehicle" value="'. $row1["vehiclename"].'" readonly> </div>
									</div>
									<div class="row row-space">
										<div class="col-2">
											<label class="label">Problem</label>
											<textarea class="input--style-4 js-datepicker" name="problem" readonly>'. $row1["problem"].' </textarea></div>
									</div>
							</div>
						</div>
					</div>
					
				</div>
			<script type="text/javascript" language="javascript">
			var locations = [['. $row1["user_latitude"].','. $row1["user_longitude"].']];
	
			var marker, i;
			
			for (i = 0; i < locations.length; i++) {
			  var map = new google.maps.Map(document.getElementById("map"), {
				zoom: 10,
				center: new google.maps.LatLng(locations[i][0], locations[i][1]),
				mapTypeId: google.maps.MapTypeId.ROADMAP
			  });
			
			  var infowindow = new google.maps.InfoWindow();
			  marker = new google.maps.Marker({
				position: new google.maps.LatLng(locations[i][0], locations[i][1]),
				map: map
			  });
			
			  google.maps.event.addListener(
				marker,
				"click",
				(function (marker, i) {
				  return function () {
					infowindow.setContent(locations[i][0]);
					infowindow.open(map, marker);
				  };
				})(marker, i)
			  );
			}
			
		</script>';
                }
                } else { echo '<h1 style="margin-top:100px;"><center>No CUSTOMER REQUESTED</center></h1>'; }
                $conn->close();
            ?>
		</div>
</body>
</html>