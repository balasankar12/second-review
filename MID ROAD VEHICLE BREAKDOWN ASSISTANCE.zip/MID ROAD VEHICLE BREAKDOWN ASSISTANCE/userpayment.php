<?php include('userlogin.php') ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
	<title>Mid Road Helper</title>
    <link href="assets/img/logo.png" rel="icon">
    <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">
    <link rel="stylesheet" href="assets/css/head.css" /> 
    <link rel="stylesheet" href="assets/css/table.css" />
	<link rel="stylesheet" href="assets/css/profile.css" />
</head>

<body>
    <div class="header">
        <div class="row" >
            <div class="logo">
                <img src="assets/img/logo.png">
            </div>
            <div >
                <div style="float:right;margin-right: 100px;color:royalblue;font-size:25px;">
                    <?php echo "Welcome ".$_SESSION['username'];?>    
                </div>
                <div class="dnav">
                    <ul class="main-nav">
                        <li style="margin-right: 400px; color:#FFFFFF"><h1>MIDROAD HELPER</h1></li>
                        <li><a href="userhome.php">HOME</a></li>
                        <li><a href="deleteuserhs.php?del=<?php echo $_SESSION['userid'];?>">CANCEL</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div >
			<?php
				include('connection.php');
				$sql1="select hs.name,p.hs_id,p.user_id,c.vehiclename,c.problem,p.amount from helperservice_details hs,connect_user_hs c,payment p where p.hs_id=hs.hs_id and c.hs_id='".$_SESSION['hsid']."' and c.status=1 and p.status=0";
				$result1 = $conn->query($sql1);
				if ($result1->num_rows > 0) {
                    
                while($row1 = $result1->fetch_assoc()) {
                echo '<div class="page-wrapper bg-gra-02 p-t-130 p-b-100 font-poppins">
			
				<h2 class="title">Detail of Customer</h2>
					<div class="wrapper wrapper--w680">
						<div class="card card-4">
							<div class="card-body">
								<form method="POST" action="payment.php">
									<div class="row row-space">
										<div class="col-2">
											<label class="label">Customer Name</label>
											<input class="input--style-4" type="text" name="hsname" value="'. $row1["name"].'" readonly> </div>
									</div>
									<div class="row row-space">
										<div class="col-2">
											<label class="label">E-Mail</label>
											<input class="input--style-4 js-datepicker" type="text" name="vehicle" value="'. $row1["vehiclename"].'" readonly> </div>
									</div>
									<div class="row row-space">
										<div class="col-2">
											<label class="label">Number</label>
											<input class="input--style-4 js-datepicker" type="text" name="problem" value="'. $row1["problem"].'" readonly> </div>
									</div>
									<div class="row row-space">
										<div class="col-2">
											<label class="label">Vehicle(*This is just mechanic fee*)</label>
											<input class="input--style-4 js-datepicker" type="text" name="amount" value="'. $row1["amount"].'" readonly> </div>
									</div>
									<div class="row row-space">
                                		<div class="col-2">
                                    		<input type="submit" class="button" value="		PAY		">
                                		</div>
                            		</div>
									<input class="input--style-4 js-datepicker" type="text" name="userid" value="'. $row1["user_id"].'" style="display: none;"   readonly></br>
									<input class="input--style-4 js-datepicker" type="text" name="hsid" value="'. $row1["hs_id"].'" style="display: none;"   readonly></br>
									<input class="input--style-4 js-datepicker" type="text" name="vehiclename" value="'. $row1["vehiclename"].'" style="display: none;"   readonly></br>
									<textarea class="input--style-4 js-datepicker" name="problem" value="'. $row1["problem"].'" style="display: none;"   readonly"></textarea></br>
								</form>
							</div>
						</div>
					</div>
					
				</div>';
            }
            } else { echo '<h1 style="margin-top:100px;"><center>wait for Helper Service confirmation</center></h1>'; }
            $conn->close();
        ?>
    </div>
    
</body>
</html>