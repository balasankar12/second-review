<?php
include('userlogin.php');
include('connecthelperservice.php');
include('connection.php');
$sql1 = "INSERT INTO connect_user_hs (user_id, hs_id,user_latitude,user_longitude,vehiclename,problem) 
    VALUES ('".$_SESSION['userid']."',{$_GET['id']},'".$_SESSION['lat']."','".$_SESSION['lng']."','".$_SESSION['vechiclename']."','".$_SESSION['problem']."')";
if ($conn->query($sql1)==TRUE){
    echo "<script>alert('Wait until helper service accepts your request....');
    window.location.href='userpayment.php';
    </script>"; 
}else{
    echo "Registration Failed";
}
?>