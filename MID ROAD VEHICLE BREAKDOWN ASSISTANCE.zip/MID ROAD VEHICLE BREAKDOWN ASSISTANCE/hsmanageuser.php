<?php
 $errors = array();

    if (isset($_POST['submit'])) { 
        include('connection.php');
        if($_POST['approval']==1){
            $sql1="update connect_user_hs set status=1 where user_id={$_GET['id']}";
            if ($conn->query($sql1)==TRUE){
                echo "<script>alert('Approved');
                window.location.href='userhschat.php';
                </script>"; 
            }else{
                echo "<script>alert('Failed');
                window.location.href='hshome.php';
                </script>";
            }
        }
        else{
            $sql1="delete from connect_user_hs where user_id={$_GET['id']}";
            if ($conn->query($sql1)==TRUE){
                echo "<script>alert('Rejected');
                window.location.href='hshome.php';
                </script>"; 
            }else{
                echo "<script>alert('Failed');
                window.location.href='hshome.php';
                </script>";
            }
        }
    }
        
?>