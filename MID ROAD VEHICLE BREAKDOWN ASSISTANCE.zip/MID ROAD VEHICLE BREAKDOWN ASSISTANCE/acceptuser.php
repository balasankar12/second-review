<?php
include('connection.php');
$userid=mysqli_real_escape_string($conn,$_POST['userid']);
$hsid=mysqli_real_escape_string($conn,$_POST['hsid']);
$amount=mysqli_real_escape_string($conn,$_POST['amount']);
$vehiclename=mysqli_real_escape_string($conn,$_POST['vehiclename']);
$problem=mysqli_real_escape_string($conn,$_POST['problem']);
    if (isset($_POST['accept'])) { 
        $sql1="update connect_user_hs set status=1 where hs_id='".$hsid."' and user_id='".$userid."'"; 
        $sql2="insert into payment(user_id,hs_id,amount,vehiclename,problem) values('$userid','$hsid','$amount','$vehiclename','$problem')";
        if ($conn->query($sql1)==TRUE&&$conn->query($sql2)) {
            echo "<script>alert('Approved');
            window.location.href='hshome.php';
            </script>"; 
        }else{
            echo "Failed";
        }
    }elseif (isset($_POST['reject']))
    {
        $sql2="delete from connect_user_hs where hs_id='".$hsid."' and user_id='".$userid."'";
        if ($conn->query($sql2)==TRUE){
            echo "<script>alert('Rejected');
            window.location.href='hshome.php';
            </script>"; 
        }else{
            echo "Failed";
        }
    }
    else{
        echo "Failed";
    }
?>