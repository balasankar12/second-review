<?php include('userlogin.php') ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
	<title>Mid Road Helper</title>
    <link href="assets/img/logo.png" rel="icon">
    <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">
    <link rel="stylesheet" href="assets/css/head.css" /> 
    <link rel="stylesheet" href="assets/css/table.css" /> 
</head>

<body>
    <div class="header">
        <div class="row" >
            <div class="logo">
                <img src="assets/img/logo.png">
            </div>
            <div >
                <div style="float:right;margin-right: 100px;color:royalblue;font-size:25px;">
                    <?php echo "Welcome ".$_SESSION['username'];?>    
                </div>
                <div class="dnav">
                    <ul class="main-nav">
                        <li style="margin-right: 400px; color:#FFFFFF"><h1>MIDROAD HELPER</h1></li>
                        <li><a href="userhome.php">HOME</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div>
    <?php
        $lat=$_POST['latitude'];
        $lng=$_POST['longitude'];
        $hs=$_POST['hs'];
                include('connection.php');
                $sql1 = "SELECT * FROM (
                    SELECT *, (((acos(sin(( $lat * pi() / 180))*
                                    sin(( latitude * pi() / 180)) + cos(( $lat * pi() /180 ))*
                                    cos(( latitude * pi() / 180)) * cos((( $lng - longitude) * pi()/180)))
                                ) * 180/pi()) * 60 * 1.1515 * 1.609344)
                                as distance FROM helperservice_details
                                ) myTable WHERE distance <= 15 and status=1 and service='$hs' LIMIT 15;";
                $result1 = $conn->query($sql1);
                if ($result1->num_rows > 0) {
                    $_SESSION['lat']=$lat;
                    $_SESSION['lng']=$lng;
                    $_SESSION['vechiclename']=$_POST['vehiclename'];
                    $_SESSION['problem']=$_POST['problem'];
                    echo '<input type="text" id="myInput" onkeyup="myFunction()" placeholder="Search for vehicle type . . . " title="Type in a name">
                <table class="customers" id="myTable" style="margin-top:0px">
                <tr>
                    <th >Name</th>
                    <th >Business Name</th>
                    <th >Email</th>
                    <th >Number</th>
                    <th> Service</th>
                    <th> Vehicle Type</th>
                    <th >Available</th>
                    <th >SELECT</th>
                </tr>';
                while($row1 = $result1->fetch_assoc()) {
                echo '
                        <tr>
                            <td >'. $row1["name"].'</td>
                            <td >'. $row1["business_name"].'</td>
                            <td >'. $row1["email"].'</td>
                            <td >'. $row1["number"].'</td>
                            <td >'. $row1["service"].'</td>
                            <td>'.$row1["vehicle_type"].'</td>
                            <td >'. $row1["available"].'</td>';
                echo "<td> <form action='connect_user_hs.php?id=".$row1['hs_id']."' method='POST'> 
                        <input type='submit' name='submit' value='select' style='width:200px'/></form></td></tr>";
                }
                } else { echo '<h1 style="margin-top:100px;"><center>No Helper Services Found</center></h1>'; }
                $conn->close();
            ?>
            </table>
    </div>
    <script>
function myFunction() {
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");
  for (i = 1; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[6];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }           
  }
}
</script>
</body>
</html>