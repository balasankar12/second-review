<?php include('hslogin.php') ?>
	<!DOCTYPE html>
	<html>

	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
		<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
		<script src="https://maps.google.com/maps/api/js?sensor=false" type="text/javascript"></script>
		<title>Online Mid-road Mechanic</title>
		<link href="assets/img/logo.png" rel="icon">
		<link rel="stylesheet" href="assets/css/head.css" />
		<link rel="stylesheet" href="assets/css/table.css" />
		<link rel="stylesheet" href="assets/css/profile.css" />
		<style type="text/css">
		#map {
			width: 200px;
			height: 200px;
		}
		#hsmap{
			width: 200px;
			height: 200px;
		}
		</style>
	</head>

	<body>
		<div class="header">
			<div class="row">
				<div class="logo"> <img src="assets/img/logo.png"> </div>
				<div>
					<div style="float:right;margin-right: 100px; color:blue;font-size:25px;">
						<?php
						include('connection.php');

						echo "WELCOME  ".strtoupper($_SESSION['hsname']);?>
					</div>
					<div class="dnav">
						<ul class="main-nav">
							<li><a href="#" onclick="toggleVisibility('home');">Home</a></li>
							<li><a href="#" onclick="toggleVisibility('hsprofile');">Profile</a></li>
							<li><?php 
                        include('connection.php');
                        $sql1 = "select hs_id from connect_user_hs where hs_id='".$_SESSION['hsid']."' and status=1";
                        $result = mysqli_query($conn, $sql1);
                        $row = mysqli_fetch_assoc($result);
                        $count = mysqli_num_rows($result);

                        if ($count) {
                            echo '<a href="hsbill.php">FIND USER</a>';
                        }
                        else {
                            echo '<a href="#" onclick="toggleVisibility(\'finduser\');">FIND USER</a>';
                        }
                        ?></li>
							<li><a href="#" onclick="toggleVisibility('feedback');">Feedback</a></li>
							<li><a href="index.html">Logout</a></li>
						</ul>
					</div>
				</div>
			</div>
		</div>
		<div id="home">
			<div style="float:left;width:40%;font-size: x-large; font-family: 'Eras Bold ITC'; font-weight: 1400; font-style: inherit;  color:dimgray;margin-left:50px;margin-top:70px">
				<p> <strong style="color:royalblue;">
                What is Roadside Assistance?
                </strong></br>
					</br> Roadside assistance is a vehicular support service offered by MidRoad Mechanic to individuals who experience a vehicular breakdown. The service typically provides benefits such as getting the vehicle fixed on the spot, refueling it, towing the vehicle to the nearest garage or a specific location, extending medical assistance and much more. MidRoad Mechanic offers the best road assistance for cars / four wheelers and two wheelers in India. </p>
			</div>
			<div style="float:right;width:40%;margin-right:100px;"> <img src="assets/img/carmechimg.jpg"> </div>
		</div>
		<div id="hsprofile" style="display: none;">
			<div class="page-wrapper bg-gra-02 p-t-130 p-b-100 font-poppins">
				<h2 class="title">PROFILE</h2>
				<div class="wrapper wrapper--w680">
					<div class="card card-4">
						<div class="card-body">
							<form method="POST">
							<div class="row row-space">
									<div class="col-2">
										<label class="label">Name</label>
										<input class="input--style-4" type="text" name="name" value="<?php echo $_SESSION['hsname'];?>" readonly> </div>
								</div>
								<div class="row row-space">
									<div class="col-2">
										<label class="label">Business Name</label>
										<input class="input--style-4" type="text" name="businessname" value="<?php echo $_SESSION['businessname'];?>" readonly> </div>
								</div>
								<div class="row row-space">
									<div class="col-2">
										<label class="label">E-Mail</label>
										<input class="input--style-4 js-datepicker" type="text" name="mail" value="<?php echo $_SESSION['email'];?>" readonly> </div>
								</div>
								<div class="row row-space">
									<div class="col-2">
										<label class="label">Number</label>
										<input class="input--style-4 js-datepicker" type="text" name="number" value="<?php echo $_SESSION['number'];?>" readonly> </div>
								</div>
								<div class="row row-space">
									<div class="col-2">
										<label class="label">Password</label>
										<input class="input--style-4 js-datepicker" type="text" name="password" value="<?php echo $_SESSION['password'];?>" readonly> </div>
								</div>
								<div class="row row-space">
									<div class="col-2">
										<label class="label">Service</label>
										<input class="input--style-4 js-datepicker" type="text" name="service" value="<?php echo $_SESSION['service'];?>" readonly> </div>
								</div>
								<div class="row row-space">
									<div class="col-2">
										<label class="label">Vehicle Type</label>
										<input class="input--style-4 js-datepicker" type="text" name="vehicletype" value="<?php echo $_SESSION['vehicle_type'];?>" readonly> </div>
								</div>
								<div class="row row-space">
									<div class="col-2">
										<label class="label">Available</label>
										<input class="input--style-4 js-datepicker" type="text" name="available" value="<?php echo $_SESSION['available'];?>" readonly> </div>
								</div>
								<div class="row row-space">
									<div class="col-2">
										<label class="label">Location:</label>
										<div id="hsmap"></div>
										<label class="label">Latitude</label>
										<input class="input--style-4 js-datepicker" id="lat" type="text" name="lat" value="<?php echo $_SESSION['latitude'];?>" readonly>
										<label class="label">Longitude</label>
										<input class="input--style-4 js-datepicker" id="lng" type="text" name="lon" value="<?php echo $_SESSION['longitude'];?>" readonly> </div>
								</div>
								<div class="row row-space">
									<div class="col-2">
										<label class="label">Status</label>
										<input class="input--style-4 js-datepicker" type="text" name="status" value="<?php if($_SESSION['status']==0){echo "PENDING";}else{echo "APPROVED";};?>" readonly> </div>
								</div>
								<div class="row row-space">
									<div class="col-2">
										<label class="label">ID-Proof</label>
										<img src="assets/img/<?php echo $_SESSION['proof'];?>"height="100" weight="100" class="hover-shadow cursor">
									</div>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
			<script type="text/javascript" language="javascript">
		var locations = [[<?php echo $_SESSION['latitude'];?>,<?php echo $_SESSION['longitude'];?>]];

		var marker, i;
		
		for (i = 0; i < locations.length; i++) {
		  var map = new google.maps.Map(document.getElementById("hsmap"), {
			zoom: 10,
			center: new google.maps.LatLng(locations[i][0], locations[i][1]),
			mapTypeId: google.maps.MapTypeId.ROADMAP
		  });
		
		  var infowindow = new google.maps.InfoWindow();
		  marker = new google.maps.Marker({
			position: new google.maps.LatLng(locations[i][0], locations[i][1]),
			map: map
		  });
		
		  google.maps.event.addListener(
			marker,
			"click",
			(function (marker, i) {
			  return function () {
				infowindow.setContent(locations[i][0]);
				infowindow.open(map, marker);
			  };
			})(marker, i)
		  );
		}
		
    </script>
		</div>
		<div id="finduser" style="display: none;">
			<?php
				include('connection.php');
				$sql1="select u.name,u.mail_id,u.number,c.user_latitude,user_longitude,c.hs_id,c.user_id,c.vehiclename,c.problem from user_details u,connect_user_hs c where u.user_id=c.user_id and c.hs_id='".$_SESSION['hsid']."' and c.status=0";
				$result1 = $conn->query($sql1);
				if ($result1->num_rows > 0) {
                    
                while($row1 = $result1->fetch_assoc()) {
                echo '<div class="page-wrapper bg-gra-02 p-t-130 p-b-100 font-poppins">
			
				<h2 class="title">Detail of Customer</h2>
					<div class="wrapper wrapper--w680">
						<div class="card card-4">
							<div class="card-body">
								<form method="POST" action="acceptuser.php">
									<div class="row row-space">
										<div class="col-2">
											<label class="label">Customer Name</label>
											<input class="input--style-4" type="text" name="cname" value="'. $row1["name"].'" readonly> </div>
									</div>
									<div class="row row-space">
										<div class="col-2">
											<label class="label">E-Mail</label>
											<input class="input--style-4 js-datepicker" type="text" name="cmail" value="'. $row1["mail_id"].'" readonly> </div>
									</div>
									<div class="row row-space">
										<div class="col-2">
											<label class="label">Number</label>
											<input class="input--style-4 js-datepicker" type="text" name="cnumber" value="'. $row1["number"].'" readonly> </div>
									</div>
									<div class="row row-space">
										<div class="col-2">
											<label class="label">Location</label>
											<div id="map"></div>
									</div>
									
									<div class="row row-space">
										<div class="col-2">
											<label class="label">Latitude</label>
											<input class="input--style-4 js-datepicker" type="text" name="lat" value="'. $row1["user_latitude"].'" readonly> </div>
									</div>
									<div class="row row-space">
										<div class="col-2">
											<label class="label">Longitude</label>
											<input class="input--style-4 js-datepicker" type="text" name="lon" value="'. $row1["user_longitude"].'" readonly> </div>
									</div>
									<div class="row row-space">
										<div class="col-2">
											<label class="label">Vehicle</label>
											<input class="input--style-4 js-datepicker" type="text" name="vehiclename" value="'. $row1["vehiclename"].'" readonly> </div>
									</div>
									<div class="row row-space">
										<div class="col-2">
											<label class="label">Problem</label>
											<textarea class="input--style-4 js-datepicker" name="problem" readonly>'. $row1["problem"].' </textarea></div>
									</div>
									<div class="row row-space">
										<div class="col-2">
											<label class="label">Amount</label>
											<input class="input--style-4 js-datepicker" type="text" name="amount" > </div>
									</div>
									<input class="input--style-4 js-datepicker" type="text" name="userid" value="'. $row1["user_id"].'" style="display: none;"   readonly></br>
									<input class="input--style-4 js-datepicker" type="text" name="hsid" value="'. $row1["hs_id"].'" style="display: none;"   readonly></br>
									<div class="p-t-15">
										<button class="btn btn--radius-2 btn--blue" type="submit" name="accept">Accept</button>
										<button class="btn btn--radius-2 btn--blue" type="submit" name="reject">Reject</button>
									</div>
								</form>
							</div>
						</div>
					</div>
					
				</div>
			<script type="text/javascript" language="javascript">
			var locations = [['. $row1["user_latitude"].','. $row1["user_longitude"].']];
	
			var marker, i;
			
			for (i = 0; i < locations.length; i++) {
			  var map = new google.maps.Map(document.getElementById("map"), {
				zoom: 10,
				center: new google.maps.LatLng(locations[i][0], locations[i][1]),
				mapTypeId: google.maps.MapTypeId.ROADMAP
			  });
			
			  var infowindow = new google.maps.InfoWindow();
			  marker = new google.maps.Marker({
				position: new google.maps.LatLng(locations[i][0], locations[i][1]),
				map: map
			  });
			
			  google.maps.event.addListener(
				marker,
				"click",
				(function (marker, i) {
				  return function () {
					infowindow.setContent(locations[i][0]);
					infowindow.open(map, marker);
				  };
				})(marker, i)
			  );
			}
			
		</script>';
                }
                } else { echo '<h1 style="margin-top:100px;"><center>No CUSTOMER REQUESTED</center></h1>'; }
                $conn->close();
            ?>
		</div>

		<div id="feedback" style="display: none;">
		<?php
						include('connection.php');
						$sql4 = "select * from feedback where hs_id='{$_SESSION['hsid']}' order by rating asc";
						$result4 = $conn->query($sql4);
						if ($result4->num_rows > 0) {
						// output data of each row
						echo '<input type="text" id="myInput" onkeyup="myFunction()" placeholder="Search.." title="Type in a name">
						<table class="customers" id="myTable">
						<tr >
							<th >Helper Service ID</th>
							<th >User Name</th>
							<th >Mail_ID</th>
							<th> Ratings</th>
							<th >Message</th>
						</tr>';
						while($row4 = $result4->fetch_assoc()) {
						echo '
								<tr >
									<td >'. $row4["hs_id"].'</td>
									<td >'. $row4["name"].'</td>
									<td >'. $row4["mail_id"].'</td>
									<td>'.$row4["rating"].'</td>
									<td >'. $row4["message"].'</td>
								</tr>';
						}
						} else { echo '<h1 style="margin-top:100px;"><center>No USERS Found</center></h1>'; }
						$conn->close();
					?>
				</table>
		</div>
		<script src="assets/js/hsprofile.js"></script>
		
		<script>
function myFunction() {
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[0];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}
</script>
	</body>

	</html>