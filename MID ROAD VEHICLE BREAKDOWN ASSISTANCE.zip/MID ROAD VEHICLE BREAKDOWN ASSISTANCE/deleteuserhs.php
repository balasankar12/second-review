<?php
include('connection.php');
$sql1="delete from connect_user_hs where user_id={$_GET['del']}";
$sql2="delete from payment where user_id={$_GET['del']} and status=0";
if ($conn->query($sql1)==TRUE && $conn->query($sql2)==TRUE){
    echo "<script>alert('Cancelled');
        window.location.href='userhome.php';
        </script>"; 
}
?>